package com.example.soundapp

import android.media.MediaPlayer
import android.os.Bundle
import android.widget.Button
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import be.tarsos.dsp.AudioEvent
import be.tarsos.dsp.AudioProcessor
import be.tarsos.dsp.filters.BandPass
import be.tarsos.dsp.io.android.AudioDispatcherFactory
import java.io.File

/**
 * MainActivity demonstrates a simple equalizer based on three frequency bands.
 * Sliders control the gain of sub‑bass (20–60 Hz), bass (60–250 Hz) and lower midrange (250–500 Hz).
 * When the user taps “Apply Equalizer”, the app processes a sample WAV file in the cache directory
 * using TarsosDSP band‑pass filters and writes the processed data to a new file.
 * For simplicity this example assumes a WAV file named input.wav exists in the cache directory.
 */
class MainActivity : AppCompatActivity() {
    private lateinit var band1Seek: SeekBar
    private lateinit var band2Seek: SeekBar
    private lateinit var band3Seek: SeekBar
    private lateinit var applyButton: Button
    private lateinit var playButton: Button
    private var mediaPlayer: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        band1Seek = findViewById(R.id.band1)
        band2Seek = findViewById(R.id.band2)
        band3Seek = findViewById(R.id.band3)
        applyButton = findViewById(R.id.applyBtn)
        playButton = findViewById(R.id.playBtn)

        // Prepare a MediaPlayer to play the original audio from a raw resource if available.
        // In a real app you might let the user select a file or record audio.
        try {
            mediaPlayer = MediaPlayer.create(this, R.raw.sample_audio)
        } catch (e: Exception) {
            Toast.makeText(this, "Unable to load sample audio", Toast.LENGTH_SHORT).show()
        }

        playButton.setOnClickListener {
            mediaPlayer?.start()
        }

        applyButton.setOnClickListener {
            processAudioWithEqualizer()
        }
    }

    /**
     * Processes the audio file stored in the cache directory using a simple equalizer built with
     * band‑pass filters. The processed file is saved as output.wav in the cache directory.
     */
    private fun processAudioWithEqualizer() {
        val inputFile = File(cacheDir, "input.wav")
        if (!inputFile.exists()) {
            Toast.makeText(this, "No input file found at ${'$'}{inputFile.absolutePath}", Toast.LENGTH_LONG).show()
            return
        }
        // In this example we process audio in memory only. To write to a file, define an output File and add
        // a WriterProcessor or WaveFileWriter.
        // val outputFile = File(cacheDir, "output.wav")

        // Dispatcher reads from the input file. Buffer size 1024 with zero overlap.
        val dispatcher = AudioDispatcherFactory.fromPipe(
            inputFile.absolutePath,
            44100,
            1024,
            0
        )

        // Convert SeekBar progress (0–100) to linear gain factor between 0 and 2.
        val gain1 = band1Seek.progress / 50f
        val gain2 = band2Seek.progress / 50f
        val gain3 = band3Seek.progress / 50f

        // Set up band‑pass filters for each band. The sample rate matches the dispatcher.
        val band1 = BandPass(40f, 40f, 44100f)  // Center ~40 Hz, bandwidth 40 Hz
        val band2 = BandPass(155f, 190f, 44100f) // Center ~155 Hz, bandwidth 190 Hz
        val band3 = BandPass(375f, 250f, 44100f) // Center ~375 Hz, bandwidth 250 Hz

        val equalizer = object : AudioProcessor {
            override fun process(event: AudioEvent?): Boolean {
                if (event == null) return true
                val input = event.floatBuffer.clone()
                val output = FloatArray(input.size) { 0f }

                // Process each band separately and sum the results multiplied by the slider gain.
                processBand(band1, input, output, gain1, event)
                processBand(band2, input, output, gain2, event)
                processBand(band3, input, output, gain3, event)

                System.arraycopy(output, 0, event.floatBuffer, 0, output.size)
                return true
            }

            override fun processingFinished() {}

            private fun processBand(
                filter: BandPass,
                input: FloatArray,
                output: FloatArray,
                gain: Float,
                event: AudioEvent
            ) {
                val tempEvent = AudioEvent(event.format, input.size)
                System.arraycopy(input, 0, tempEvent.floatBuffer, 0, input.size)
                filter.process(tempEvent)
                for (i in output.indices) {
                    output[i] += tempEvent.floatBuffer[i] * gain
                }
            }
        }

        // Add the equalizer processor to the dispatcher.
        dispatcher.addAudioProcessor(equalizer)

        // Run the dispatcher on a background thread. For simplicity this example does not write
        // the processed audio to a file. In a real app you can attach a WriterProcessor
        // or WaveFileWriter to persist the output.
        Thread {
            dispatcher.run()
            runOnUiThread {
                Toast.makeText(this, "Processing completed. The audio buffer was processed in memory.", Toast.LENGTH_LONG).show()
            }
        }.start()
    }
}